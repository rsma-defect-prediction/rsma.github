#' Github datasets for rsma
#'
#' This package contains 4 datasets for software defect prediction: \cr
#' \code{\link[rsma.github]{github_class_1.0}} \cr
#' \code{\link[rsma.github]{github_class_1.1}} \cr
#' \code{\link[rsma.github]{github_file_1.0}} \cr
#' \code{\link[rsma.github]{github_file_1.1}} \cr
#'
#' The software metrics in these datasets have been computed from 15 Github projects
#' in Java:
#' \itemize{
#'   \item Android Universal Image Loader: library for loading, caching and displaying
#'   images on Android.
#'   \item ANTLR4 (ANother Tool for Language Recognition): parser generator for reading
#'   and processing structured text.
#'   \item Broadleaf Commerce: open source eCommerce platform (based on Spring
#'   framework).
#'   \item Ceylon IDE Eclipse: plugin for Eclipse IDE.
#'   \item Elastic Search: search engine based on the Lucene library.
#'   \item Hazelcast: open source in-memory data grid (based in Java).
#'   \item Junit: unit testing framework for Java.
#'   \item MapDB: provides Java Maps, Sets, Lists, Queues and other collections
#'   backed by off-heap or on-disk storage.
#'   \item mcMMO: server-side RPG mod for Minecraft videogame.
#'   \item MCT (Mission Control Technologies): web based mission control framework
#'   for data visualization.
#'   \item Neo4j: graph database management system.
#'   \item Netty: non-blocking I/O client-server framework for the development
#'   of Java network applications.
#'   \item OrientDB: open source NoSQL database management system.
#'   \item Oryx: cloud-based dental software.
#'   \item Titan: software for facility maintenance, environmental compliance,
#'   fuel analytics, and wetstock management.
#' }
#'
#' @source
#' \link{http://www.inf.u-szeged.hu/~ferenc/papers/GitHubBugDataSet/}.
#'
#' @references
#' Zoltan Toth, Peter Gyimesi, Rudolf Ferenc: A Public Bug Database of GitHub Projects
#' and Its Application in Bug Prediction, In Computational Science and Its Applications - ICCSA 2016.
#' Lecture Notes in Computer Science, vol 9789. Springer, Cham.
#'
#' @docType package
#' @name rsma.github
NULL
