#' Github projects datasets (class level)
#'
#' Github datasets of software metrics for different projects (version 1.0).
#'
#' These metrics are used for software defect prediction (supervised learning
#' models).
#'
#' @format The variables are:
#' \describe{
#'   \item{project}{Name of the project}
#'   \item{date}{Six months intervals}
#'   \item{ID}{Class ID}
#'   \item{Name}{Class name}
#'   \item{LongName}{Extended class name}
#'   \item{Parent}{Parent ID}
#'   \item{Component}{Component ID}
#'   \item{Path}{Directory path}
#'   \item{Line}{Starting line}
#'   \item{Column}{Starting column}
#'   \item{EndLine}{Ending line}
#'   \item{EndColumn}{Ending column}
#'   \item{CC}{Cylomatic complexity}
#'   \item{CCL}{Not available}
#'   \item{CCO}{Not available}
#'   \item{CI}{Not available}
#'   \item{CLC}{Not available}
#'   \item{CLLC}{Not available}
#'   \item{LDC}{Not available}
#'   \item{LLDC}{Not available}
#'   \item{LCOM5}{Lack of cohesion methods (CK)}
#'   \item{NL}{Not available}
#'   \item{NLE}{Not available}
#'   \item{WMC}{Weighted method count (CK)}
#'   \item{CBO}{Coupling between objects (CK)}
#'   \item{CBOI}{Not available}
#'   \item{NII}{Not available}
#'   \item{NOI}{Number of interfaces}
#'   \item{RFC}{Response for a class (CK)}
#'   \item{AD}{Anonymous declarations}
#'   \item{CD}{Class declarations}
#'   \item{CLOC}{Comment lines of code}
#'   \item{DLOC}{Not available}
#'   \item{PDA}{Not available}
#'   \item{PUA}{Not available}
#'   \item{TCD}{Not available}
#'   \item{TCLOC}{Total comment lines of code}
#'   \item{DIT}{Depth of inheritance tree (CK)}
#'   \item{NOA}{Number of attributes}
#'   \item{NOC}{Number of children (CK)}
#'   \item{NOD}{Number of operands}
#'   \item{NOP}{Number of operators}
#'   \item{LLOC}{Logical lines of code}
#'   \item{LOC}{Lines of code}
#'   \item{NA.}{Not available}
#'   \item{NG}{Not available}
#'   \item{NLA}{Not available}
#'   \item{NLG}{Not available}
#'   \item{NLM}{Not available}
#'   \item{NLPA}{Not available}
#'   \item{NLPM}{Not available}
#'   \item{NLS}{Not available}
#'   \item{NM}{Number of methods}
#'   \item{NOS}{Not available}
#'   \item{NPA}{Number of public attributes}
#'   \item{NPM}{Number of public methods}
#'   \item{NS}{Not available}
#'   \item{TTLOC}{Total logical lines of code}
#'   \item{TLOC}{Total lines of code}
#'   \item{TNA}{Not available}
#'   \item{TNG}{Not available}
#'   \item{TNLA}{Not available}
#'   \item{TNLG}{Not available}
#'   \item{TNLM}{Not available}
#'   \item{TNLPA}{Not available}
#'   \item{TNLPM}{Not available}
#'   \item{TNLS}{Not available}
#'   \item{TNM}{Not available}
#'   \item{TNOS}{Not available}
#'   \item{TNPA}{Not available}
#'   \item{TNPM}{Not available}
#'   \item{TNS}{Not available}
#'   \item{WarningBlocker}{Number of blocker warnings}
#'   \item{WarningCritical}{Number of critical warnings}
#'   \item{WarningInfo}{Number of warning informations}
#'   \item{WarningMajor}{Number of major warnings}
#'   \item{WarningMinor}{Number of minor warnings}
#'   \item{Android.Rules}{Number of android rule violations}
#'   \item{Basic.Rules}{Number of basic rule violations}
#'   \item{Brace.Rules}{Number of brace rule violations}
#'   \item{Clone.Implementation.Rules}{Number of clone implementation rule violations}
#'   \item{Clone.Metric.Rules}{Number of clone metric rule violations}
#'   \item{Code.Size.Rules}{Number of code size rule violations}
#'   \item{Cohesion.Metric.Rules}{Number of cohesion metric rule violations}
#'   \item{Comment.Rules}{Number of comment rule violations}
#'   \item{Complexity.Metric.Rules}{Number of complexity metric rule violations}
#'   \item{Controversial.Rules}{Number of controversial rule violations}
#'   \item{Coupling.Metric.Rules}{Number of coupling metric rule violations}
#'   \item{Coupling.Rules}{Number of coupling rule violations}
#'   \item{Design.Rules}{Number of design rule violations}
#'   \item{Documentation.Metric.Rules}{Number of documentation metric rule violations}
#'   \item{Empty.Code.Rules}{Number of empty code rule violations}
#'   \item{Finalizer.Rules}{Number of finalizer rule violations}
#'   \item{Import.Statement.Rules}{Number of import statement rule violations}
#'   \item{Inheritance.Metric.Rules}{Number of inheritance metric rule violations}
#'   \item{J2EE.Rules}{Number of J2EE rule violations}
#'   \item{JUnit.Rules}{Number of JUnit rule violations}
#'   \item{Jakarta.Commons.Logging.Rules}{Number of Jakarta commons logging rule violations}
#'   \item{Java.Logging.Rules}{Number of Java logging rule violations}
#'   \item{JavaBean.Rules}{Number of JavaBean rule violations}
#'   \item{MigratingToJUni4.Rules}{Number of migratingToJUnit4 rule violations}
#'   \item{Migration.Rules}{Number of migration rule violations}
#'   \item{Migration13.Rules}{Number of migration13 rule violations}
#'   \item{Naming.Rules}{Number of naming rule violations}
#'   \item{Optimization.Rules}{Number of optimization rule violations}
#'   \item{Security.Code.Guideline.Rules}{Number of security code guideline rule violations}
#'   \item{Size.Metric.Rules}{Number of size metric rule violations}
#'   \item{Strict.Exception.Rules}{Number of strict exception rule violations}
#'   \item{String.and.StringBuffer.Rules}{Number of string and string buffer rule violations}
#'   \item{Type.Resolution.Rules}{Number of type resolution rule violations}
#'   \item{Unnecessary.and.Unused.Code.Rules}{Number of unnecessary and unused code rule violations}
#'   \item{Vulnerability.Rules}{Number of vulnerability rule violations}
#'   \item{Number.of.bugs}{Number of bugs found}
#' }
#'
#' @source \url{http://www.inf.u-szeged.hu/~ferenc/papers/GitHubBugDataSet/}
"github_class_1.0"

#' Github projects datasets (class level)
#'
#' Github datasets of software metrics for different projects (version 1.1).
#'
#' These metrics are used for software defect prediction (supervised learning
#' models).
#'
#' @format The variables are:
#' \describe{
#'   \item{project}{Name of the project}
#'   \item{date}{Six months intervals}
#'   \item{ID}{Class ID}
#'   \item{Name}{Class name}
#'   \item{LongName}{Extended class name}
#'   \item{Parent}{Parent ID}
#'   \item{Component}{Component ID}
#'   \item{Path}{Directory path}
#'   \item{Line}{Starting line}
#'   \item{Column}{Starting column}
#'   \item{EndLine}{Ending line}
#'   \item{EndColumn}{Ending column}
#'   \item{CC}{Cylomatic complexity}
#'   \item{CCL}{Not available}
#'   \item{CCO}{Not available}
#'   \item{CI}{Not available}
#'   \item{CLC}{Not available}
#'   \item{CLLC}{Not available}
#'   \item{LDC}{Not available}
#'   \item{LLDC}{Not available}
#'   \item{LCOM5}{Lack of cohesion methods (CK)}
#'   \item{NL}{Not available}
#'   \item{NLE}{Not available}
#'   \item{WMC}{Weighted method count (CK)}
#'   \item{CBO}{Coupling between objects (CK)}
#'   \item{CBOI}{Not available}
#'   \item{NII}{Not available}
#'   \item{NOI}{Number of interfaces}
#'   \item{RFC}{Response for a class (CK)}
#'   \item{AD}{Anonymous declarations}
#'   \item{CD}{Class declarations}
#'   \item{CLOC}{Comment lines of code}
#'   \item{DLOC}{Not available}
#'   \item{PDA}{Not available}
#'   \item{PUA}{Not available}
#'   \item{TCD}{Not available}
#'   \item{TCLOC}{Total comment lines of code}
#'   \item{DIT}{Depth of inheritance tree (CK)}
#'   \item{NOA}{Number of attributes}
#'   \item{NOC}{Number of children (CK)}
#'   \item{NOD}{Number of operands}
#'   \item{NOP}{Number of operators}
#'   \item{LLOC}{Logical lines of code}
#'   \item{LOC}{Lines of code}
#'   \item{NA.}{Not available}
#'   \item{NG}{Not available}
#'   \item{NLA}{Not available}
#'   \item{NLG}{Not available}
#'   \item{NLM}{Not available}
#'   \item{NLPA}{Not available}
#'   \item{NLPM}{Not available}
#'   \item{NLS}{Not available}
#'   \item{NM}{Number of methods}
#'   \item{NOS}{Not available}
#'   \item{NPA}{Number of public attributes}
#'   \item{NPM}{Number of public methods}
#'   \item{NS}{Not available}
#'   \item{TTLOC}{Total logical lines of code}
#'   \item{TLOC}{Total lines of code}
#'   \item{TNA}{Not available}
#'   \item{TNG}{Not available}
#'   \item{TNLA}{Not available}
#'   \item{TNLG}{Not available}
#'   \item{TNLM}{Not available}
#'   \item{TNLPA}{Not available}
#'   \item{TNLPM}{Not available}
#'   \item{TNLS}{Not available}
#'   \item{TNM}{Not available}
#'   \item{TNOS}{Not available}
#'   \item{TNPA}{Not available}
#'   \item{TNPM}{Not available}
#'   \item{TNS}{Not available}
#'   \item{WarningBlocker}{Number of blocker warnings}
#'   \item{WarningCritical}{Number of critical warnings}
#'   \item{WarningInfo}{Number of warning informations}
#'   \item{WarningMajor}{Number of major warnings}
#'   \item{WarningMinor}{Number of minor warnings}
#'   \item{Android.Rules}{Number of android rule violations}
#'   \item{Basic.Rules}{Number of basic rule violations}
#'   \item{Brace.Rules}{Number of brace rule violations}
#'   \item{Clone.Implementation.Rules}{Number of clone implementation rule violations}
#'   \item{Clone.Metric.Rules}{Number of clone metric rule violations}
#'   \item{Code.Size.Rules}{Number of code size rule violations}
#'   \item{Cohesion.Metric.Rules}{Number of cohesion metric rule violations}
#'   \item{Comment.Rules}{Number of comment rule violations}
#'   \item{Complexity.Metric.Rules}{Number of complexity metric rule violations}
#'   \item{Controversial.Rules}{Number of controversial rule violations}
#'   \item{Coupling.Metric.Rules}{Number of coupling metric rule violations}
#'   \item{Coupling.Rules}{Number of coupling rule violations}
#'   \item{Design.Rules}{Number of design rule violations}
#'   \item{Documentation.Metric.Rules}{Number of documentation metric rule violations}
#'   \item{Empty.Code.Rules}{Number of empty code rule violations}
#'   \item{Finalizer.Rules}{Number of finalizer rule violations}
#'   \item{Import.Statement.Rules}{Number of import statement rule violations}
#'   \item{Inheritance.Metric.Rules}{Number of inheritance metric rule violations}
#'   \item{J2EE.Rules}{Number of J2EE rule violations}
#'   \item{JUnit.Rules}{Number of JUnit rule violations}
#'   \item{Jakarta.Commons.Logging.Rules}{Number of Jakarta commons logging rule violations}
#'   \item{Java.Logging.Rules}{Number of Java logging rule violations}
#'   \item{JavaBean.Rules}{Number of JavaBean rule violations}
#'   \item{MigratingToJUni4.Rules}{Number of migratingToJUnit4 rule violations}
#'   \item{Migration.Rules}{Number of migration rule violations}
#'   \item{Migration13.Rules}{Number of migration13 rule violations}
#'   \item{Naming.Rules}{Number of naming rule violations}
#'   \item{Optimization.Rules}{Number of optimization rule violations}
#'   \item{Security.Code.Guideline.Rules}{Number of security code guideline rule violations}
#'   \item{Size.Metric.Rules}{Number of size metric rule violations}
#'   \item{Strict.Exception.Rules}{Number of strict exception rule violations}
#'   \item{String.and.StringBuffer.Rules}{Number of string and string buffer rule violations}
#'   \item{Type.Resolution.Rules}{Number of type resolution rule violations}
#'   \item{Unnecessary.and.Unused.Code.Rules}{Number of unnecessary and unused code rule violations}
#'   \item{Vulnerability.Rules}{Number of vulnerability rule violations}
#'   \item{Number.of.bugs}{Number of bugs found}
#' }
#'
#' @source \url{http://www.inf.u-szeged.hu/~ferenc/papers/GitHubBugDataSet/}
"github_class_1.1"

#' Github projects datasets (file level)
#'
#' Github datasets of software metrics for different projects (version 1.0).
#'
#' These metrics are used for software defect prediction (supervised learning
#' models).
#'
#' @format The variables are:
#' \describe{
#'   \item{classname}{Name of the project}
#'   \item{date}{Six months intervals}
#'   \item{ID}{Class ID}
#'   \item{Name}{Class name}
#'   \item{LongName}{Extended class name}
#'   \item{Parent}{Parent ID}
#'   \item{McCC}{McCabe's Cylomatic Complexity}
#'   \item{CLOC}{Comment lines of code}
#'   \item{LLOC}{Logical lines of code}
#'   \item{Number.of.committers}{Number of people who commited a change}
#'   \item{Number.of.developer.commits}{Number of total commits made by all developers for that file}
#'   \item{Number.of.previous.modifications}{Number of previous modifications of the file}
#'   \item{Number.of.previous.fixes}{Number of previous fixes}
#'   \item{Number.of.bugs}{Number of bugs found}
#' }
#'
#' @source \url{http://www.inf.u-szeged.hu/~ferenc/papers/GitHubBugDataSet/}
"github_file_1.0"

#' Github projects datasets (file level)
#'
#' Github datasets of software metrics for different projects (version 1.1).
#'
#' These metrics are used for software defect prediction (supervised learning
#' models).
#'
#' @format The variables are:
#' \describe{
#'   \item{classname}{Name of the project}
#'   \item{date}{Six months intervals}
#'   \item{ID}{Class ID}
#'   \item{Name}{Class name}
#'   \item{LongName}{Extended class name}
#'   \item{Parent}{Parent ID}
#'   \item{McCC}{McCabe's Cylomatic Complexity}
#'   \item{CLOC}{Comment lines of code}
#'   \item{LLOC}{Logical lines of code}
#'   \item{Number.of.committers}{Number of people who commited a change}
#'   \item{Number.of.developer.commits}{Number of total commits made by all developers for that file}
#'   \item{Number.of.previous.modifications}{Number of previous modifications of the file}
#'   \item{Number.of.previous.fixes}{Number of previous fixes}
#'   \item{Number.of.bugs}{Number of bugs found}
#' }
#'
#' @source \url{http://www.inf.u-szeged.hu/~ferenc/papers/GitHubBugDataSet/}
"github_file_1.1"
